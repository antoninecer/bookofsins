<?php
   define('DB_SERVER', 'localhost');
   define('DB_USERNAME', 'registr');
   define('DB_PASSWORD', 'RegHes123');
   define('DB_DATABASE', 'registr');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>
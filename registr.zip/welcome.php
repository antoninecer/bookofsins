<?php
   include('session.php');
?>
<html">
   
   <head>
      <title>Registr </title>
	  <meta charset="UTF-8">
   </head>
   
   <body>
    <?php include('menu.php'); ?>
      <br>
	  <br>
	  Sem napsat o co jde a jak se s tim pracuje
	  <br>
	  při hledání % najde vše
	  
	  <hr>
	  
   </body>
   
</html>
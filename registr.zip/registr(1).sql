-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Počítač: 127.0.0.1:3306
-- Vytvořeno: Sob 09. úno 2019, 18:05
-- Verze serveru: 5.7.24
-- Verze PHP: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáze: `registr`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `hrich`
--

DROP TABLE IF EXISTS `hrich`;
CREATE TABLE IF NOT EXISTS `hrich` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_hrisnika` int(11) DEFAULT NULL,
  `vlozil` varchar(50) COLLATE utf8_czech_ci NOT NULL,
  `datum` datetime NOT NULL,
  `h1` tinyint(1) NOT NULL DEFAULT '0',
  `h2` tinyint(1) NOT NULL DEFAULT '0',
  `h3` tinyint(1) NOT NULL DEFAULT '0',
  `h4` tinyint(1) NOT NULL DEFAULT '0',
  `h5` tinyint(1) NOT NULL DEFAULT '0',
  `h6` tinyint(1) NOT NULL DEFAULT '0',
  `h7` tinyint(1) NOT NULL DEFAULT '0',
  `h8` tinyint(1) NOT NULL DEFAULT '0',
  `h9` tinyint(1) NOT NULL DEFAULT '0',
  `h10` tinyint(1) NOT NULL DEFAULT '0',
  `popis` text COLLATE utf8_czech_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `hrich`
--

INSERT INTO `hrich` (`id`, `id_hrisnika`, `vlozil`, `datum`, `h1`, `h2`, `h3`, `h4`, `h5`, `h6`, `h7`, `h8`, `h9`, `h10`, `popis`) VALUES
(6, 8, 'tonda', '2019-02-05 22:25:20', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(8, 9, 'pepe', '2019-02-05 22:56:51', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(29, 20, 'jan', '2019-02-07 23:05:33', 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, ''),
(28, 20, 'pepe', '2019-02-07 23:03:18', 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, ''),
(33, 25, 'tonda', '2019-02-08 12:02:20', 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 'PÃ­chÃ¡ za prachy'),
(34, 25, 'tonda', '2019-02-08 12:02:57', 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 'PÃ­chÃ¡ za prachy'),
(37, 29, 'jan', '2019-02-09 17:48:28', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, ''),
(38, 30, 'tonda', '2019-02-09 17:57:53', 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 'Otravuje lidi prey fb'),
(39, 30, 'zlaty strom', '2019-02-09 18:03:58', 1, 0, 1, 1, 0, 0, 0, 0, 1, 0, ''),
(40, 30, 'tonda', '2019-02-09 18:16:23', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'n2co');

-- --------------------------------------------------------

--
-- Struktura tabulky `hrichy`
--

DROP TABLE IF EXISTS `hrichy`;
CREATE TABLE IF NOT EXISTS `hrichy` (
  `nazev` varchar(5) COLLATE utf8_czech_ci NOT NULL,
  `popis` varchar(150) COLLATE utf8_czech_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `hrichy`
--

INSERT INTO `hrichy` (`nazev`, `popis`) VALUES
('h1', 'Okradl Podnik'),
('h2', 'Okradl Kolegu'),
('h3', 'Okradl Hosta'),
('h4', 'Alkohol'),
('h5', 'Drogy'),
('h6', 'Absence'),
('h7', 'Pozdni prichody'),
('h8', 'Stahovani Zamestnancu'),
('h9', 'Lhani');

-- --------------------------------------------------------

--
-- Struktura tabulky `hrisnici`
--

DROP TABLE IF EXISTS `hrisnici`;
CREATE TABLE IF NOT EXISTS `hrisnici` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `jmeno` varchar(50) COLLATE utf8_czech_ci NOT NULL,
  `prijmeni` varchar(50) COLLATE utf8_czech_ci NOT NULL,
  `narozeni` varchar(50) COLLATE utf8_czech_ci NOT NULL,
  `vlozil` varchar(50) COLLATE utf8_czech_ci DEFAULT NULL,
  `datum` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `hrisnici`
--

INSERT INTO `hrisnici` (`id`, `jmeno`, `prijmeni`, `narozeni`, `vlozil`, `datum`) VALUES
(20, 'Jojo', 'jojatÃ½', '2000-05-04', 'pepe', '2019-02-07 23:02:48'),
(25, 'Pepina', 'Pipina', '1994-03-14', 'tonda', '2019-02-08 12:01:48'),
(29, 'Jelito', 'Kopito', '2011-11-13', 'jan', '2019-02-09 17:48:18'),
(30, 'Lenka', 'novakova', '1990-05-10', 'tonda', '2019-02-09 17:56:38');

-- --------------------------------------------------------

--
-- Struktura tabulky `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8_czech_ci NOT NULL,
  `passcode` varchar(50) COLLATE utf8_czech_ci NOT NULL,
  `popis` varchar(255) COLLATE utf8_czech_ci DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `admin` tinyint(1) NOT NULL DEFAULT '1',
  `email` varchar(80) COLLATE utf8_czech_ci DEFAULT NULL,
  `telefon` varchar(20) COLLATE utf8_czech_ci DEFAULT NULL,
  `vlozil` varchar(50) COLLATE utf8_czech_ci DEFAULT NULL,
  `datum` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `users`
--

INSERT INTO `users` (`id`, `username`, `passcode`, `popis`, `active`, `admin`, `email`, `telefon`, `vlozil`, `datum`) VALUES
(2, 'tonda', 'tonda', 'administrator jÃ¡ to se divim moc se divim', 1, 1, 'antoninecer@gmail.com', '+420 733 674 242', NULL, NULL),
(3, 'jirka', 'jirka', 'zadavatel', 1, 1, 'jirka@centrum.cz', '776666655', NULL, NULL),
(24, 'zlaty strom', '1414', 'diskoteka', 1, 0, 'prostzlz@seyna.cz', '602123456', 'tonda', '2019-02-09 18:00:53'),
(20, 'jan', 'aaa', '', 1, 0, 'kraus@centrum.cz', '603234568', 'tonda', '2019-02-07 23:05:03'),
(25, 'perina', 'perina', 'agency', 1, 1, '', '', 'tonda', '2019-02-09 19:01:16'),
(23, 'uuuuu', 'uuuuu', '', 1, 0, '', '', 'tonda', '2019-02-08 14:41:34');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
